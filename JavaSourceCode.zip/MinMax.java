package com.gmail.craigmit.verletdemo;

public class MinMax {
        public float min;
        public float max;
}
